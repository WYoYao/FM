
// 周期实例
function Cycle(type) {
    return {
        "start_time": {
            "cycle": type,             //周期,y/m/w/d
            "time_week": "1",
            "time_season": "1",
            "time_month": "1",
            "time_day": "1",          //周一，1号，“0612”,6月12日
            "time_hour": "0",        //10时
            "time_minute": "0"       //15分
        },
        "end_time": {
            "cycle": type,
            "time_week": "1",
            "time_season": "1",
            "time_month": "1",
            "time_day": "1",
            "time_hour": "0",
            "time_minute": "0"
        }
    };
}

//  模糊设置的频率周期
function Interval(count, unit) {

    return {
        count: count,
        unit: unit,
    }
}


// 创建计划类
function AddWoPlan() {
    return {
        "execute": "1", // 执行人数 后期字段会有修改
        "plan_name": "",                //工单计划名称 ,必须
        "order_type": "",               //工单类型编码 ,必须
        "urgency": "低",                  //紧急程度,高、中、低 ,必须
        "ahead_create_time": 24,           //提前创建工单时间 ,必须
        "freq_cycle": "m",                 //计划频率-周期,y/m/w/d ,必须
        "freq_num": 1,                     //计划频率-次数 ,必须
        "freq_times": [                    //计划频率-时间 ,必须
        ],
        "interval": {},
        "sendTypes": "1",
        "plan_start_type": "1",             //计划开始类型,1-发布成功后立即，2-指定时间 ,必须
        "plan_start_time": "",             //计划开始时间,yyyyMMddhhmmss
        "plan_end_time": "",               //计划结束时间,yyyyMMddhhmmss，空值时代表一直有效
        "next_route": [],						//下级路由，预览后的next_route，必须
        "draft_matters": [],               //工单事项数组,草稿的matters  ,必须
        "published_matters": []            //工单事项数组,预览后的matters  ,必须      
    }
}

v.pushComponent({
    name: "createPlan",
    data: {
        // 是否是引用计划  项目中引用计划 部分基本信息不可编辑
        isQuote: false,
        // 是否是项目版创建编辑计划 项目版创建编辑计划 需要设置计划生效时间
        isTerm: false,
        //  是否是编辑计划
        isEdit: false,
        // 添加计划所用实例
        addWoPlan: {
            freq_times: [],
            next_route: [],
            draft_matters: [],
            published_matters: [],
            interval: {},
        },
        // 工单类型枚举
        WorkOrderType: [],
        // 紧急程度枚举
        urgencyType: [{ "name": "高", "code": "高" }, { "name": "中", "code": "中" }, { "name": "低", "code": "低" }],
        // 日 周 月 季 年 枚举
        freq_cycleType: [{ name: "日", code: "d" }, { name: "周", code: "w" }, { name: "月", code: "m" }, { name: "季", code: "s" }, { name: "年", code: "y" },],
        // 精确设置
        sendTypes: [{ name: "精确设置", code: "1" }, { name: "模糊设置", code: "0" }],
        // 计划开始类型
        plan_start_type: [{ name: "发布成功后立即", code: "1" }, { name: "指定时间", code: "2" }],
        // 计划结束时间
        plan_end_time_type: [{ name: "发布成功后立即", code: "1" }, { name: "指定时间", code: "2" }],
        // weekType 每周所有枚举
        weekType: [{ name: "周一", code: 1 }, { name: "周二", code: 2 }, { name: "周三", code: 3 }, { name: "周四", code: 4 }, { name: "周五", code: 5 }, { name: "周六", code: 6 }, { name: "周日", code: 7 },],
        // 季度枚举
        seasonType: [{ name: "第一个月", code: 1 }, { name: "第二个月", code: 2 }, { name: "第三个月", code: 3 },],
    },
    methods: {
        // 绑定计划频率数组
        addfreq_times: function (type, count, bool) {

            var _that = this, difference;

            if (!bool) {
                _that.addWoPlan.freq_times = [];
                return;
            }

            //  传入数字不规范直接返回空
            if (_.isNaN(+count)) {
                _that.freq_times = [];
            }

            // 绑定对应下拉菜单
            difference = _that.addWoPlan.freq_times.length - count;
            // 如果是 当前数据为空的时候直接添加
            if (difference == 0) {
                _that.addWoPlan.freq_times = _.range(count).map(function () {
                    return new Cycle(type);
                });
            } else if (difference < 0) {
                // 比之前大的时候要保证之前的值不做改变
                _that.addWoPlan.freq_times = _that.addWoPlan.freq_times.concat(_.range(Math.abs(difference)).map(function () {
                    return new Cycle(type);
                }))
            } else if (difference > 0) {
                // 减少的时候保证之前的值不改变
                _that.addWoPlan.freq_times.splice(-1, difference);
            }

            _that.bind_fres_times();
        },
        bind_fres_times: function () {
            var _that = this;

            return new Promise(function (resolve) {
                _that.$nextTick(function () {
                    var startTimes = $(".StartTime"),
                        endTimes = $(".EndTime"),
                        StartSeason = $(".StartSeason"),
                        EndSeason = $(".EndSeason"),
                        StartWeek = $(".StartWeek"),
                        EndWeek = $(".EndWeek");

                    // 循环给对应的Dom 赋值
                    _that.addWoPlan.freq_times.forEach(function (item, index) {
                        startTimes.eq(index).psel({ y: 2018, M: item.start_time.time_month, d: item.start_time.time_day, h: item.start_time.time_hour, m: item.start_time.time_minute });
                        endTimes.eq(index).psel({ y: 2018, M: item.end_time.time_month, d: item.end_time.time_day, h: item.end_time.time_hour, m: item.end_time.time_minute });

                        // 周和季度默认选中下拉框
                        if (item.cycle == "s") {
                            StartSeason.eq(index).psel(item.start_time.time_season - 1);
                            EndSeason.eq(index).psel(item.end_time.time_season - 1);
                        }

                        if (item.cycle == "w") {
                            StartWeek.eq(index).psel(item.start_time.time_week - 1);
                            EndWeek.eq(index).psel(item.start_time.time_week - 1);
                        }
                    });

                    resolve()
                })
            })
        }
    },
    computed: {
        cycleTypes: function () {
            var index = _.findIndex(this.freq_cycleType, { code: this.addWoPlan.freq_cycle })
            return this.freq_cycleType.slice(0, index);
        }
    },
    watch: {
        "addWoPlan.plan_start_type": function (value, old) {
            var _that = this;
            if (value == old) return;

            _that.addWoPlan.plan_start_time = value == 2 ? new Date().format("yyyyMMddhhmmss") : "";
        },
        //  监听频率精度
        "addWoPlan.sendTypes": function (value, old) {
            var _that = this;
            if (value == old) return;

            //  重置时间阶段
            _that.addWoPlan.freq_cycle = "m";
            _that.addWoPlan.freq_num = 1;

            if (!+value) {

                _that.addWoPlan.interval = new Interval(1, "m");
                _that.addWoPlan.freq_times = [];
            } else {
                this.addfreq_times(_that.addWoPlan.freq_cycle, _that.addWoPlan.freq_num, _that.addWoPlan.sendTypes)
            }
        },
        //  监听频率次数
        "addWoPlan.freq_num": function (value, old) {

            if (value == old) return;

            this.addfreq_times(this.addWoPlan.freq_cycle, value, this.addWoPlan.sendTypes)
        },
        // 监听频率周期
        "addWoPlan.freq_cycle": function (value, old) {
            if (value == old) return;
            this.addfreq_times(value, this.addWoPlan.freq_num, this.addWoPlan.sendTypes)
        },
        addWoPlan: function (newValue, oldValue) {

            var _that = this;

            /**
             *  找到单个实例对应数据集的索引,然后选中该索引对应的下拉菜单
             * @param {脏值检查中检查到不同的实例} item 
             */
            function destory(item) {

                var selector = {};

                selector.code = item.value;

                index = _.findIndex(cbx[item.key], selector);

                changeComboxbyKey(item.key, index, false);
            }

            createCheck(destory)(newValue, oldValue, Object.keys(cbx));
        }
    },
    beforeMount: function (addWoPlan, isQuote, isTerm) {

        var _that = this;
        // 显示当前页面
        _that.onPage = "createPlan";
        //  判断是否是编辑计划
        _that.isEdit = _.isPlainObject(addWoPlan);
        //  如果是编辑计划赋值
        if (_that.isEdit) _that.addWoPlan = addWoPlan;
        // 是否引用
        if (_.isBoolean(isQuote)) _that.isQuote = isQuote;
        // 是否项目版
        if (_.isBoolean(isTerm)) _that.isTerm = isTerm;
        // 加载工单状态类型
        var WorkOrderTypePromise = controller.queryWorkOrderType().then(function (res) {

            res.forEach(function (item) {
                _that.WorkOrderType.push(item);
            })

            return new Promise(function (resolve) {
                resolve(res);
            });

        }).catch(function () {
            _that.WorkOrderType = [];
        })

        //  选项加载完毕 附加默认值
        WorkOrderTypePromise.then(function () {

            var addWoPlan = { "execute": "11", "plan_name": "计划名称计划名称", "order_type": "13", "urgency": "中", "ahead_create_time": "11", "freq_cycle": "s", "freq_num": "4", "freq_times": [{ "start_time": { "cycle": "s", "time_week": "1", "time_season": 1, "time_month": "01", "time_day": "01", "time_hour": "00", "time_minute": "01" }, "end_time": { "cycle": "s", "time_week": "1", "time_season": "1", "time_month": "01", "time_day": "02", "time_hour": "00", "time_minute": "02" } }, { "start_time": { "cycle": "s", "time_week": "1", "time_season": "1", "time_month": "01", "time_day": "03", "time_hour": "00", "time_minute": "03" }, "end_time": { "cycle": "s", "time_week": "1", "time_season": "1", "time_month": "01", "time_day": "04", "time_hour": "00", "time_minute": "04" } }, { "start_time": { "cycle": "s", "time_week": "1", "time_season": "1", "time_month": "01", "time_day": "05", "time_hour": "00", "time_minute": "05" }, "end_time": { "cycle": "s", "time_week": "1", "time_season": "1", "time_month": "01", "time_day": "06", "time_hour": "00", "time_minute": "06" } }, { "start_time": { "cycle": "s", "time_week": "1", "time_season": "1", "time_month": "01", "time_day": "07", "time_hour": "00", "time_minute": "07" }, "end_time": { "cycle": "s", "time_week": "1", "time_season": "1", "time_month": "01", "time_day": "08", "time_hour": "00", "time_minute": "08" } }], "interval": {}, "sendTypes": "1", "plan_start_type": "1", "plan_start_time": "", "plan_end_time": "", "next_route": [], "draft_matters": [], "published_matters": [] };

            // 编辑情况
            if (addWoPlan) {

                new Promise(function (resolve) {
                    //  绑定基础信息
                    _that.addWoPlan = JSON.parse(JSON.stringify(addWoPlan));
                    _that.$nextTick(resolve);
                }).then(function () {
                    _that.addWoPlan.sendTypes = addWoPlan.sendTypes;
                    return new Promise(function (resolve) {
                        _that.$nextTick(resolve)
                    })
                }).then(function () {
                    _that.addWoPlan.freq_num = addWoPlan.freq_num;
                    _that.addWoPlan.freq_cycle = addWoPlan.freq_cycle;
                    return new Promise(function (resolve) {
                        _that.$nextTick(resolve)
                    })
                }).then(function () {

                    _that.addWoPlan.freq_times = JSON.parse(JSON.stringify(addWoPlan.freq_times))

                    _that.bind_fres_times().then(function () {
                        console.log('加载完毕');
                    })

                })

            } else {

                // 新建情况
                v.instance.addWoPlan = new AddWoPlan()
            }
        })
    }
})